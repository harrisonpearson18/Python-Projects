#Determines the area of a rectangle with given height and width in meters
height = input("Please enter the height of the given rectangle in meters: ")
width = input("Please enter the width of the given rectangle in meters: ")
height = float(height)
width = float(width)
area = height * width
print("The area of the rectangle with the given parameters is",area, "meters.")