#Program 1: Takes an integer from keyboard and provides multiplication table up to x10
# Would be much easier to use a loop :)
integer = input("Please enter a whole number: ")
integer1 = int(integer)
result = integer1 * 1
print(result)
result = integer1 * 2
print(result)
result = integer1 * 3
print(result)
result = integer1 * 4
print(result)
result = integer1 * 5
print(result)
result = integer1 * 6
print(result)
result = integer1 * 7
print(result)
result = integer1 * 8
print(result)
result = integer1 * 9
print(result)
result = integer1 * 10
print(result)
