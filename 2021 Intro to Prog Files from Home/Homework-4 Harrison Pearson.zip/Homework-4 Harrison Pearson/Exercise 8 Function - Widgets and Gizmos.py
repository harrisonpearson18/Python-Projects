# Exercise 8: Widgets and Gizmos function

def WidandGiz(input1W,input2G):
    weightW = input1W * 75
    weightG = input2G * 112
    total = weightG + weightW
    print("The total weight in grams is",total)
widgets = int(input("Please enter the number of widgets purchased: "))
gizmos = int(input("Please enter the number of gizmos purchased: "))

WidandGiz(widgets,gizmos)

