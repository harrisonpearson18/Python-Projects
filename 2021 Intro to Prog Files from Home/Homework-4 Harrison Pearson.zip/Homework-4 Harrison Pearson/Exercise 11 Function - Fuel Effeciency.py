# Exercise 11: Fuel Effeciency function

def fuelEff(input1):
    result = 235.215 / input1

    print("The given Miles/Gallon converted to L/100KM is:",result)
    return None
milesPerGallon = float(input("Please enter a MPG value to be converted to L/100KM: "))

fuelEff(milesPerGallon)























