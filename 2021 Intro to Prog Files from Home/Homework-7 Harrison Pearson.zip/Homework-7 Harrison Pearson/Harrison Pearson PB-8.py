# Right Triangle Star Pattern

ctr = 0
row = 0
while(ctr<5):
    ctr += 1
    row +=1
    print('*'*row)