# Square star pattern

ctr = 0
while(ctr < 5):
    ctr += 1
    print('*'*5)
