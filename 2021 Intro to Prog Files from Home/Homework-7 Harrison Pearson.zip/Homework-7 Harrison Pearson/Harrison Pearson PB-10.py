# Mirrored Right Triangle Star Pattern

ctr = 0
space = 5

while(ctr<5):
    ctr +=1
    space -=1
    print(' '*space+'*'*ctr)