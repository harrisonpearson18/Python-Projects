# Mirrored Rhombus star pattern

ctr = 0
row = 0

while(ctr<5):
    ctr +=1
    row +=1
    print(' '*row + '*'*5)