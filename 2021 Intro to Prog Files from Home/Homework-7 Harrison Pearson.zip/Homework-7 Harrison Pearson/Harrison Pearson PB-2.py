# Hollow square star pattern

ctr = 0
while(ctr<5):
    ctr += 1
    if(ctr==1 or ctr==5):
        print('*'*5)
    else:
        print('*   *')
