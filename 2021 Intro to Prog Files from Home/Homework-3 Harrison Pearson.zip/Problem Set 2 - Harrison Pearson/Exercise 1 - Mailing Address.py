# Exercise 1 : Mailing Address
# Program that displays name and mailing address formatted like an envelope
# Alias - John Doe - 1225 Smith Ave SW, Atlanta, GA, 35363

print("From: John Doe")
print("1225 Smith Ave SW")
print("Atlanta, GA 35363")
