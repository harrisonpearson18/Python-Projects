# Exercise 2: Hello
# Takes name input from user and says hello using their name

name = input("Please enter your name: ")
print("Hello, " + name + ", it is nice to see you!")
