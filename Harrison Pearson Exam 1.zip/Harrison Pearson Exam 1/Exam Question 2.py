# Devlop a program that reads a four-digit integer from the user and displays the sum of the digits in the number
# Example : 3+1+4+1 = 9

integer = int(input("Please enter a four-digit integer: "))

numberOne = integer // 1000
remaining = integer % 1000
numberTwo = remaining // 100
remaining = remaining % 100
numberThree = remaining // 10
remaining = remaining % 10
numberFour = remaining // 1

total = numberOne + numberTwo + numberThree + numberFour

print(numberOne,"+", numberTwo, "+",numberThree,"+",numberFour,"=",total)
