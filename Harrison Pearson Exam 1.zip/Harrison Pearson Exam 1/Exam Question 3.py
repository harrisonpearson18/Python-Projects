# Exam Question 3 : Takes user input as a cent value and converts to change, including loonies and toonies

centsInput = int(input("Pleas enter an integer of cents to be converted to change: "))

def changeMake(cents):
    toonies = cents // 200
    remaining = cents % 200
    print("Toonies:",toonies)

    loonies = remaining // 100
    remaining = remaining % 100
    print("Loonies:",loonies)

    quarter = remaining // 25
    remaining = remaining % 25
    print("Quarters:",quarter)

    dime = remaining // 10
    remaining = remaining % 10
    print("Dimes:",dime)

    nickle = remaining // 5
    remaining = remaining % 5
    print("Nickles:",nickle)

    penny = remaining // 1
    print("Pennies:",penny)


changeMake(centsInput)
