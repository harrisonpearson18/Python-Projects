# INSTRUCTIONS:
# Card game between two players.
# They are playing with TWO decks of cards
# The decks need to be shuffled and then distributed between players
# - Make sure each player gets the alternating card while distributing

# Start Game:
# At random pick a player to go first
# First player puts the top card from his stack on the board (ie last item in his list)
# Second player does the same
# Each round compare the FACE VALUE OF THE CARDS
# If FACE VALUE matches, the last player to match the card wins and collects all cards from the board
# WINNER will lay down the first card going into the next round
# If either players hand becomes empty before matching - reshuffle the cards on the board and distribute as per above rules.
# Keep track of how many ROUNDS are played (whenever a player wins)
# !!! Criteria to end game is player has all 104 cards (BOTH DECKS)!!!
# Harrison Pearson

import math, random

# Creates a set deck of TWO decks worth face value then shuffles into deck[]
def createDeck():
    deck = []
    count = 0
    while (count < 8):
        count+=1
        for x in range(1,14):
            deck.append(str(x))
    random.shuffle(deck)
    return deck
# Distributes deck from createDeck() into p1 deck for every even card in list
def distributeDeckP1(deck):
    p1_deck = deck[1::2]
    random.shuffle(p1_deck)
    return p1_deck
# Distibutes set deck from createDeck() into p2 deck for every odd card in list
def distributeDeckP2(deck):
    p2_deck = deck[0::2]
    random.shuffle(p2_deck)
    return p2_deck
# Distribute board every even card into p1 deck
def distributeBoardP1(p1_deck,board):

    p1_deck += board[1::2]
    random.shuffle(p1_deck)
    return p1_deck
# Distribute board every odd card into p2 deck
def distributeBoardP2(p2_deck,board):
    p2_deck += board[0::2]
    random.shuffle(p2_deck)
    return p2_deck



# Start Game Code
deck = createDeck()
p1_deck = distributeDeckP1(deck)
p2_deck = distributeDeckP2(deck)
board = []
draw = 0
pulls = 0
round = 0
p1_wins = 0
p2_wins = 0
lastdraw = 0
win = 0
game = True
print("FIRST PLAYER TO OBTAIN ALL 104 CARDS WINS")
print("=== BEGIN GAME ===")
while(game):
    randomNum = random.randint(1, 2)
    # End Display for when p1 or p2 wins , ending while loop

    if(len(p1_deck)==104):
        p1 = str(p1_wins)
        p2 = str(p2_wins)
        r = str(round)
        b = str(len(board))
        t = str(len(p1_deck))
        g = str(len(p2_deck))
        p = str(pulls)
        print("=======================================================================")
        print("Player 1 wins the game!")
        print("Score: P1: "+p1+ " P2: "+p2)
        print("Total rounds: "+r)
        print("Total draws: "+p)
        print("P1 total cards: "+t)
        print("P2 total cards: "+g)
        print("Cards left on board:"+b)
        print("=======================================================================")
        game = False

    elif(len(p2_deck)==104):
        p1 = str(p1_wins)
        p2 = str(p2_wins)
        r = str(round)
        b = str(len(board))
        g = str(len(p1_deck))
        t = str(len(p2_deck))
        p = str(pulls)
        print("=======================================================================")
        print("Player 2 wins the game!")
        print("Score: P1: "+p1+ " P2: "+p2)
        print("Total rounds: "+r)
        print("Total draws: "+p)
        print("P1 total cards: "+g)
        print("P2 total cards: "+t)
        print("Cards left on board:"+b)
        print("=======================================================================")
        game = False
    # Reshuffle decks and empty board when a player's hand is empty
    elif(len(p1_deck)== 0 or len(p2_deck)== 0):
        print("Player ran out of cards, reshuffling from board..")
        p1_deck = distributeBoardP1(p1_deck,board)
        random.shuffle(p1_deck)
        p2_deck = distributeBoardP2(p2_deck,board)
        random.shuffle(p1_deck)
        del board[:]
        draw = 0
    # Determines if it is round 1 or if random player needs to be selected after a reshuffle
    elif draw == 0:
        # 1 for player1 draw, 2 for player2 draw
        draw+=1
        # Rolls player 1
        if randomNum == 1:
            pulls += 1
            random.shuffle(p1_deck)
            print("Player 1 selected to draw..")
            lastdraw = 1
            p1_hand = p1_deck[-1]
            p2_hand = p2_deck[-1]
            board.append(p1_hand)
            board.append(p2_hand)
            del p1_deck[-1], p2_deck[-1]
            print("Player 1 Hand: "+p1_hand+ " Player 2 Hand: "+p2_hand)
            if (p2_hand == p1_hand):
                round += 1
                print("Player 2 wins!")
                p2_deck += board
                del board[:]
                p2_wins += 1
                win = 2
        # Rolls player 2
        if randomNum == 2:
            pulls+=1
            random.shuffle(p2_deck)
            print("Player 2 selected to draw..")
            lastdraw = 2
            p1_hand = p1_deck[-1]
            p2_hand = p2_deck[-1]
            board.append(p1_hand)
            board.append(p2_hand)
            del p1_deck[-1], p2_deck[-1]
            print("Player 1 Hand: "+p1_hand+ " Player 2 Hand: "+p2_hand)
            if (p1_hand == p2_hand):
                round += 1
                print("Player 1 wins!")
                p1_deck += board
                del board[:]
                p1_wins += 1
                win = 1

    # Checks to make sure both players have more than 0 cards in their deck before proceeding with next draw
    # "lastdraw" is used to determine which player went last, also allowing program to set value as needed to read winner
    # Whenever a winner is selected, "lastdraw" is updated making said player draw the next card
    elif(len(p1_deck)>0 and len(p2_deck)>0):

        if lastdraw == 2:
            lastdraw = 1
            pulls +=1
            p1_hand = p1_deck[-1]
            p2_hand = p2_deck[-1]
            board.append(p1_hand)
            board.append(p2_hand)
            del p1_deck[-1], p2_deck[-1]
            print("Player 1's Draw")
            print("Player 1 Hand: " + p1_hand + " Player 2 Hand: " + p2_hand)
            if (p2_hand == p1_hand):
                round += 1
                print("Player 2 wins!")
                p2_deck += board
                del board[:]
                p2_wins += 1
                lastdraw = 2


        elif lastdraw == 1 or win == 2:
            lastdraw = 2
            pulls +=1
            p1_hand = p1_deck[-1]
            p2_hand = p2_deck[-1]
            board.append(p1_hand)
            board.append(p2_hand)
            del p1_deck[-1], p2_deck[-1]
            print("Plater 2's Draw")
            print("Player 1 Hand: "+p1_hand+ " Player 2 Hand: "+p2_hand)
            if (p1_hand == p2_hand):
                round += 1
                print("Player 1 wins!")
                p1_deck += board
                del board[:]
                p1_wins += 1
                lastdraw = 1











